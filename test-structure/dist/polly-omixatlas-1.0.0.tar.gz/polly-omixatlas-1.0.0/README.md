# How to setup 

1. ` python3 -m venv venv `
2. ` source venv/bin/activate `
3. ` pip install -r requirements.txt `
4.  
    - ` PYTHONPATH="." python examples/<EXAMPLE-FILE>.py ` OR 
    - ` export PYTHONPATH="."; python examples/<EXAMPLE-FILE>.py `